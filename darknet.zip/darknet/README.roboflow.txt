
Object_detect_19/03/2021 - v2 canaa_dos_carajas
==============================

This dataset was exported via roboflow.ai on March 25, 2021 at 9:37 PM GMT

It includes 1729 images.
Objectdetect1903/2021 are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


