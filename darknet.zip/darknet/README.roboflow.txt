
Object_detect_19/03/2021 - v1 Object_detect_19/03/2021
==============================

This dataset was exported via roboflow.ai on March 19, 2021 at 11:52 PM GMT

It includes 1191 images.
Objectdetect1903/2021 are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


